# Import the library
from data_governance_checkup import compliance, lineage, rbac, metadata, masking

# Example data for the checks
gdpr_data = [
    {"user_id": 1, "name": "John Doe", "email": "john.doe@example.com", "dob": "1990-01-01"},
    {"user_id": 2, "name": "Jane Smith", "email": "jane.smith@example.com", "dob": "1985-05-12"},
]

hipaa_data = [
    {"patient_id": 1, "name": "Alice Brown", "diagnosis": "Flu", "insurance": "XYZ Health"},
    {"patient_id": 2, "name": "Bob White", "diagnosis": "Cold", "insurance": "ABC Care"},
]

data_pipeline = {
    "source": "raw_data_storage",
    "transformations": [
        {"step": 1, "operation": "normalize", "details": "Standardizing columns"},
        {"step": 2, "operation": "filter", "details": "Removing null values"},
    ],
    "destination": "processed_data_storage",
}

rbac_policy = {
    "roles": {
        "admin": {"permissions": ["read", "write", "delete"]},
        "user": {"permissions": ["read"]},
    },
    "users": {
        "john_doe": "admin",
        "jane_smith": "user",
    },
}

metadata_sample = {
    "tables": [
        {"name": "users", "columns": ["id", "name", "email", "created_at"]},
        {"name": "transactions", "columns": ["id", "user_id", "amount", "timestamp"]},
    ]
}

sensitive_data = [
    {"id": 1, "name": "Alice", "ssn": "123-45-6789", "email": "alice@example.com"},
    {"id": 2, "name": "Bob", "ssn": "987-65-4321", "email": "bob@example.com"},
]

# Example: Run GDPR Compliance Check
print("Running GDPR Compliance Check...")
gdpr_results = compliance.run_gdpr_check(gdpr_data)
print(f"GDPR Compliance Results:\n{gdpr_results}")

# Example: Run HIPAA Compliance Check
print("\nRunning HIPAA Compliance Check...")
hipaa_results = compliance.run_hipaa_check(hipaa_data)
print(f"HIPAA Compliance Results:\n{hipaa_results}")

# Example: Data Lineage Tracking
print("\nTracking Data Lineage...")
lineage_results = lineage.track_lineage(data_pipeline)
print(f"Data Lineage:\n{lineage_results}")

# Example: Role-Based Access Control (RBAC) Auditing
print("\nAuditing Role-Based Access Control...")
rbac_results = rbac.audit_rbac(rbac_policy)
print(f"RBAC Audit Results:\n{rbac_results}")

# Example: Metadata Management
print("\nCataloging Metadata...")
metadata_catalog = metadata.catalog_metadata(metadata_sample)
print(f"Metadata Catalog:\n{metadata_catalog}")

# Example: Data Masking and Anonymization
print("\nApplying Data Masking and Anonymization...")
masked_data = masking.mask_and_anonymize(sensitive_data)
print(f"Masked and Anonymized Data:\n{masked_data}")
