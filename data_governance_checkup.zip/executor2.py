from data_governance_checkup.compliance.gdpr import GDPRCompliance
from data_governance_checkup.compliance.hipaa import HIPAACompliance
from data_governance_checkup.compliance.iso27001 import ISO27001Compliance
from data_governance_checkup.compliance.ccpa import CCPACompliance

# Sample data
data = {
    "personal_data": "John Doe",
    "PHI": "Medical Record",
    "PHI_encrypted": False,
    "backup_enabled": False,
    "sensitive_data_access": [{"user": "alice", "logged": False}],
    "data_sold": True,
    "consumer_consent": False,
}

# Run compliance checks
gdpr_violations = GDPRCompliance.check(data)
hipaa_violations = HIPAACompliance.check(data)
iso_violations = ISO27001Compliance.check(data)
ccpa_violations = CCPACompliance.check(data)

# Print results
print("GDPR Violations:", gdpr_violations)
print("HIPAA Violations:", hipaa_violations)
print("ISO 27001 Violations:", iso_violations)
print("CCPA Violations:", ccpa_violations)
